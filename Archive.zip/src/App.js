import React, { useState } from 'react';
import UserList from './components/UserList';
import UserForm from './components/UserForm';

const App = () => {
    const [currentUser, setCurrentUser] = useState(null);
    const [showForm, setShowForm] = useState(false);

    const handleEdit = (user) => {
        setCurrentUser(user);
        setShowForm(true);
    };

    const handleAddUser = () => {
        setCurrentUser(null);
        setShowForm(true);
    };

    const handleSave = () => {
        setShowForm(false);
        setCurrentUser(null);
    };

    const handleCancel = () => {
        setShowForm(false);
        setCurrentUser(null);
    };

    return (
        <div className="App container">
            <h1 className="my-3">React Axios CRUD</h1>
            {showForm ? (
                <UserForm currentUser={currentUser} onSave={handleSave} onCancel={handleCancel} />
            ) : (
                <UserList onEdit={handleEdit} onAddUser={handleAddUser} />
            )}
        </div>
    );
};

export default App;