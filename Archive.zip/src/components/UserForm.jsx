import React, { useState, useEffect } from 'react';
import { addUser, updateUser } from '../services/api';

const UserForm = ({ currentUser, onSave, onCancel }) => {
    const [user, setUser] = useState({ name: '', email: '' });

    useEffect(() => {
        if (currentUser) {
            setUser(currentUser);
        }
    }, [currentUser]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (user.id) {
                await updateUser(user.id, user);
            } else {
                await addUser(user);
            }
            onSave(); // Refresh the user list
        } catch (error) {
            console.error("Error saving user:", error);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="m-3">
            <div className="mb-3">
                <label className="form-label">Name:</label>
                <input type="text" name="name" value={user.name} onChange={handleChange} className="form-control" required />
            </div>
            <div className="mb-3">
                <label className="form-label">Email:</label>
                <input type="email" name="email" value={user.email} onChange={handleChange} className="form-control" required />
            </div>
            <div className="mb-3">
                <label className="form-label">Email:</label>
                <input type="text" name="phone" value={user.phone} onChange={handleChange} className="form-control" required />
            </div>
            <button type="submit" className="btn btn-primary">Save</button>
            <button type="button" onClick={onCancel} className="btn btn-secondary ms-2">Cancel</button>
        </form>
    );
};

export default UserForm;